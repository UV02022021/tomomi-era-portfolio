
/// <reference types="vite/client" />

